from PIL import Image
import numpy as np

def identify_flag(image_path):
    img = Image.open(image_path).convert('RGBA')
    arr = np.array(img)
    
    # Only consider non-transparent pixels
    mask = arr[:, :, 3] > 128  # alpha > 128 (half-transparent)
    rgb_arr = arr[:, :, :3]
    
    # Split into top and bottom halves
    h = arr.shape[0]
    top_mask = np.zeros(mask.shape, dtype=bool)
    bottom_mask = np.zeros(mask.shape, dtype=bool)
    top_mask[:h//2, :] = True
    bottom_mask[h//2:, :] = True
    
    # Combine masks
    top_valid = mask & top_mask
    bottom_valid = mask & bottom_mask
    
    # Calculate mean color, ignoring background
    if np.sum(top_valid) == 0 or np.sum(bottom_valid) == 0:
        return "Flag not recognized"
    avg_top = np.mean(rgb_arr[top_valid], axis=0)
    avg_bottom = np.mean(rgb_arr[bottom_valid], axis=0)
    
    def is_red(color):
        r, g, b = color
        return r > 100 and g < 80 and b < 80
    
    def is_white(color):
        r, g, b = color
        return r > 180 and g > 180 and b > 180
    
    if is_red(avg_top) and is_white(avg_bottom):
        return "Indonesia"
    elif is_white(avg_top) and is_red(avg_bottom):
        return "Poland"
    else:
        return "Flag not recognized"

if __name__ == "__main__":
    # Make sure your image filename matches exactly (case and extension)
     result = identify_flag("abhishek/gangorce/poland.jpeg")  # Replace with your actual filename, e.g., "indonesia.jpg"
     print(result)

